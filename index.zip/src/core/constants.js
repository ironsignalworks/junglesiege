export const HUD_HEIGHT = 96;
export const PLAY_MARGIN = 8;
