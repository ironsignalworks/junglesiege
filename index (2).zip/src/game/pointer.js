// src/input/pointer.js
import { state } from "../core/state.js";
import { firePlayerBullet } from "./projectiles.js";
import { constants } from "./constants.js";

function toCanvasXY(canvas, clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const x = ((clientX - rect.left) / rect.width) * canvas.width;
  const y = ((clientY - rect.top)  / rect.height) * canvas.height;
  return [x, y];
}

export function attachPointer() {
  const canvas = state.canvas || document.getElementById("gameCanvas");
  if (!canvas) {
    console.warn("[pointer] no canvas yet; will retry on next startGame()");
    return;
  }
  if (canvas._pointerBound) return;
  canvas._pointerBound = true;

  const onMouseMove = (e) => {
    const [cx, cy] = toCanvasXY(canvas, e.clientX, e.clientY);
    state.pointerX = cx;
    state.pointerY = cy;
  };

  const onMouseDown = (e) => {
    e.preventDefault();
    try { firePlayerBullet(); } catch {}
  };

  const onTouchMove = (e) => {
    e.preventDefault();
    const t = e.touches[0];
    if (!t) return;
    const [cx, cy] = toCanvasXY(canvas, t.clientX, t.clientY);
    state.pointerX = cx;
    state.pointerY = cy;
  };

  const onTouchStart = (e) => {
    e.preventDefault();
    try { firePlayerBullet(); } catch {}
  };

  canvas.addEventListener("mousemove", onMouseMove);
  canvas.addEventListener("mousedown", onMouseDown);
  canvas.addEventListener("touchmove", onTouchMove, { passive: false });
  canvas.addEventListener("touchstart", onTouchStart, { passive: false });

  // FIXED: Only smooth X-follow, DO NOT override Y position for keyboard movement
  if (!state._pointerFollowTimer) {
    state._pointerFollowTimer = setInterval(() => {
      if (!state.gameStarted) return;
      const { pointerX, tank } = state;
      if (!tank || !Number.isFinite(pointerX)) return;

      // Only apply pointer following for X axis - and only if no keyboard input is active
      if (!state.keyLeft && !state.keyRight) {
        tank.x += (pointerX - (tank.x + tank.width / 2)) * 0.22;
      }

      const c = state.canvas;
      if (!c) return;
      
      // Clamp X position
      tank.x = Math.max(0, Math.min(c.width - tank.width, tank.x));

      // REMOVED: Y position override that was preventing keyboard movement
      // tank.y = c.height - bottomBar - tank.height;
    }, 30);
  }

  console.log("[pointer] bound");
}
